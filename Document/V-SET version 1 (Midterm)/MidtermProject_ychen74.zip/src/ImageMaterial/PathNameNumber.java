package ImageMaterial;

public class PathNameNumber {
	public String Path;
	public String Name;
	public int Number;
	
	public PathNameNumber(String Path, String Name, int Number){
		this.Path = Path;
		this.Name = Name;
		this.Number = Number;
	}
}
