package Variables;

public class SystemControl {
	public static int loadingMode;
	
	public SystemControl(){
		loadingMode = 1;
	}
}
