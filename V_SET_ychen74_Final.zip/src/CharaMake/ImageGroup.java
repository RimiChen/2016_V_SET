package CharaMake;

import java.util.List;

import ImageMaterial.PathNameNumber;

public interface ImageGroup {
	public List<PathNameNumber> getImagePathList();
}
